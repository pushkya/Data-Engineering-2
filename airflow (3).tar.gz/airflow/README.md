# Problem Statement

A music streaming company, Sparkify, has decided that it is time to introduce more automation and monitoring to their data warehouse ETL pipelines and come to the conclusion that the best tool to achieve this is Apache Airflow.

They have decided to bring you into the project and expect you to create high grade data pipelines that are dynamic and built from reusable tasks, can be monitored, and allow easy backfills. 


# Objectives

- To create high grade data pipelines that are dynamic and built from reusable tasks
- Easy monitoring
- Allow easy backfills
- To process data in Redshift


# Datasets

Here are the s3 links for each:
- Log data: s3://udacity-dend/log_data
- Song data: s3://udacity-dend/song_data


# Building the operators
All of the operators and task instances will run SQL statements against the Redshift database

## Stage Operator
The stage operator is expected to be able to load any JSON formatted files from S3 to Amazon Redshift. The operator creates and runs a SQL COPY statement based on the parameters provided. The operator's parameters should specify where in S3 the file is loaded and what is the target table. nother important requirement of the stage operator is containing a templated field that allows it to load timestamped files from S3 based on the execution time and run backfills.

## Facts and Dimensiins Operator
With dimension and fact operators, you can utilize the provided SQL helper class to run data transformations. Most of the logic is within the SQL transformations and the operator is expected to take as input a SQL statement and target database on which to run the query against

## Data Quality Operator
The final operator to create is the data quality operator, which is used to run checks on the data itself. The operator's main functionality is to receive one or more SQL based test cases along with the expected results and execute the tests. For each the test, the test result and expected result needs to be checked and if there is no match, the operator should raise an exception and the task should retry and fail eventually.


# Database Schema

### Staging tables
- staging_events
- staging_songs

### Fact Table
#### songplays : records in event data associated with song plays i.e. records with page NextSong 
songplay_id, start_time, user_id, level, song_id, artist_id, session_id, location, user_agent

### Dimension tables:
#### users : users in the app
user_id, first_name, last_name, gender, level

#### songs : songs in music database
song_id, title, artist_id, year, duration

#### artists : artists in music database
artist_id, name, location, lattitude, longitude

#### time - timestamps of records in songplays broken down into specific units
start_time, hour, day, week, month, year, weekday


# File structure
- **airflow:** workspace folder containing the airflow DAGs and plugins used by the airflow server.
- **airflow/dags/udac_example_dag.py:** Main DAG file in Python containing all steps of the pipeline.
- - **airflow/dags/create_tables.sql:** Sql file which creates the facts and dimensions tables
- **airflow/plugins/operators/:** Folder containing custom operators which can be called inside an Airflow DAG. 
